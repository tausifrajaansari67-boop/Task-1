// FocusLens Background Service Worker
// Tracks active tab time and classifies websites

const PRODUCTIVE_SITES = [
  "github.com", "gitlab.com", "stackoverflow.com", "leetcode.com",
  "codepen.io", "replit.com", "dev.to", "medium.com", "notion.so",
  "docs.google.com", "figma.com", "linear.app", "jira.atlassian.com",
  "trello.com", "asana.com", "coursera.org", "udemy.com", "khan academy.org",
  "edx.org", "pluralsight.com", "codecademy.com", "freecodecamp.org",
  "developer.mozilla.org", "w3schools.com", "npmjs.com", "pypi.org",
  "claude.ai", "chat.openai.com", "google.com", "wikipedia.org",
  "arxiv.org", "scholar.google.com", "overleaf.com"
];

const UNPRODUCTIVE_SITES = [
  "facebook.com", "instagram.com", "twitter.com", "x.com", "tiktok.com",
  "snapchat.com", "reddit.com", "pinterest.com", "tumblr.com",
  "youtube.com", "netflix.com", "twitch.tv", "disneyplus.com",
  "primevideo.com", "hulu.com", "9gag.com", "buzzfeed.com",
  "dailymail.co.uk", "tmz.com", "espn.com", "sportsnet.ca"
];

const NEUTRAL_SITES = [
  "gmail.com", "mail.google.com", "outlook.com", "yahoo.com",
  "amazon.com", "flipkart.com", "myntra.com", "zomato.com", "swiggy.com"
];

function classifySite(hostname) {
  const h = hostname.replace(/^www\./, "").toLowerCase();
  if (PRODUCTIVE_SITES.some(s => h.includes(s))) return "productive";
  if (UNPRODUCTIVE_SITES.some(s => h.includes(s))) return "unproductive";
  if (NEUTRAL_SITES.some(s => h.includes(s))) return "neutral";
  return "neutral";
}

function getHostname(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function getWeekKey() {
  const d = new Date();
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(d.setDate(diff));
  return `week-${monday.getFullYear()}-${String(monday.getMonth()+1).padStart(2,"0")}-${String(monday.getDate()).padStart(2,"0")}`;
}

let activeTab = null;
let activeStart = null;

async function saveTime(hostname, seconds) {
  if (!hostname || seconds < 1) return;
  const today = getTodayKey();
  const weekKey = getWeekKey();
  const category = classifySite(hostname);

  const result = await chrome.storage.local.get(["dailyData", "weeklyData", "allSites"]);
  let daily = result.dailyData || {};
  let weekly = result.weeklyData || {};
  let allSites = result.allSites || {};

  // Daily data
  if (!daily[today]) daily[today] = { productive: 0, unproductive: 0, neutral: 0, sites: {} };
  daily[today][category] = (daily[today][category] || 0) + seconds;
  if (!daily[today].sites[hostname]) daily[today].sites[hostname] = { seconds: 0, category };
  daily[today].sites[hostname].seconds += seconds;

  // Weekly aggregate
  if (!weekly[weekKey]) weekly[weekKey] = { productive: 0, unproductive: 0, neutral: 0, days: {} };
  weekly[weekKey][category] = (weekly[weekKey][category] || 0) + seconds;
  if (!weekly[weekKey].days[today]) weekly[weekKey].days[today] = { productive: 0, unproductive: 0, neutral: 0 };
  weekly[weekKey].days[today][category] = (weekly[weekKey].days[today][category] || 0) + seconds;

  // All sites
  if (!allSites[hostname]) allSites[hostname] = { seconds: 0, category };
  allSites[hostname].seconds += seconds;
  allSites[hostname].category = category;

  // Keep only last 90 days of daily data
  const keys = Object.keys(daily).sort();
  if (keys.length > 90) {
    delete daily[keys[0]];
  }

  await chrome.storage.local.set({ dailyData: daily, weeklyData: weekly, allSites });
}

async function flushActiveTab() {
  if (activeTab && activeStart) {
    const elapsed = Math.round((Date.now() - activeStart) / 1000);
    await saveTime(activeTab, elapsed);
    activeStart = Date.now();
  }
}

// Track tab changes
chrome.tabs.onActivated.addListener(async (info) => {
  await flushActiveTab();
  try {
    const tab = await chrome.tabs.get(info.tabId);
    const hostname = getHostname(tab.url);
    activeTab = hostname;
    activeStart = Date.now();
  } catch {
    activeTab = null;
    activeStart = null;
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (active && active.id === tabId) {
      await flushActiveTab();
      activeTab = getHostname(tab.url);
      activeStart = Date.now();
    }
  }
});

// Handle idle state
chrome.idle.setDetectionInterval(60);
chrome.idle.onStateChanged.addListener(async (state) => {
  if (state === "idle" || state === "locked") {
    await flushActiveTab();
    activeTab = null;
    activeStart = null;
  } else if (state === "active") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      activeTab = getHostname(tab.url);
      activeStart = Date.now();
    }
  }
});

// Window focus
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await flushActiveTab();
    activeTab = null;
    activeStart = null;
  } else {
    const [tab] = await chrome.tabs.query({ active: true, windowId });
    if (tab) {
      activeTab = getHostname(tab.url);
      activeStart = Date.now();
    }
  }
});

// Flush every 30 seconds via alarm
chrome.alarms.create("flush", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "flush") {
    await flushActiveTab();
  }
});

// Weekly report notification every Sunday at 9am
chrome.alarms.create("weeklyReport", {
  when: getNextSunday9AM(),
  periodInMinutes: 60 * 24 * 7
});

function getNextSunday9AM() {
  const now = new Date();
  const day = now.getDay();
  const daysUntilSunday = (7 - day) % 7 || 7;
  const sunday = new Date(now);
  sunday.setDate(now.getDate() + daysUntilSunday);
  sunday.setHours(9, 0, 0, 0);
  return sunday.getTime();
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "weeklyReport") {
    const result = await chrome.storage.local.get("weeklyData");
    const weekly = result.weeklyData || {};
    const weekKey = getWeekKey();
    const data = weekly[weekKey] || { productive: 0, unproductive: 0, neutral: 0 };
    const total = data.productive + data.unproductive + data.neutral;
    const score = total > 0 ? Math.round((data.productive / total) * 100) : 0;

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "FocusLens Weekly Report",
      message: `Productivity score: ${score}%. Productive: ${formatTime(data.productive)}, Unproductive: ${formatTime(data.unproductive)}. Open dashboard for full report.`
    });
  }
});

function formatTime(secs) {
  if (secs < 60) return `${secs}s`;
  if (secs < 3600) return `${Math.round(secs/60)}m`;
  return `${(secs/3600).toFixed(1)}h`;
}

// Expose data via message passing
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_STATS") {
    flushActiveTab().then(() => {
      chrome.storage.local.get(["dailyData", "weeklyData", "allSites"]).then(result => {
        sendResponse({ success: true, data: result });
      });
    });
    return true;
  }
  if (msg.type === "CLASSIFY") {
    sendResponse({ category: classifySite(msg.hostname) });
  }
  if (msg.type === "ADD_CUSTOM_SITE") {
    chrome.storage.local.get("customClassifications").then(r => {
      const custom = r.customClassifications || {};
      custom[msg.hostname] = msg.category;
      chrome.storage.local.set({ customClassifications: custom }).then(() => {
        sendResponse({ success: true });
      });
    });
    return true;
  }
  if (msg.type === "CLEAR_DATA") {
    chrome.storage.local.clear().then(() => sendResponse({ success: true }));
    return true;
  }
});
