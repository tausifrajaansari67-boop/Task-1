# 🔍 FocusLens — Chrome Extension for Time Tracking & Productivity Analytics

## Features
- **Real-time tracking** — tracks time spent on every website automatically
- **Smart classification** — auto-classifies 30+ sites as Productive, Unproductive, or Neutral
- **Live popup** — see today's score, top sites, and current active tab at a glance
- **Full dashboard** — 5-page analytics dashboard with charts and insights
- **Weekly reports** — Sunday 9AM notification with your weekly productivity score
- **Custom classifications** — override any site's category
- **Export** — download your data as JSON or CSV
- **Streak tracking** — tracks consecutive productive days

## Installation (Chrome / Edge)

1. **Download/unzip** this folder to your computer
2. Open Chrome and go to `chrome://extensions`
3. Enable **Developer Mode** (toggle in top-right)
4. Click **Load unpacked**
5. Select the `time-tracker-extension` folder
6. The FocusLens icon will appear in your Chrome toolbar

## Usage
- Click the **extension icon** in your toolbar to see today's overview
- Click **Open Dashboard** (or right-click → Options) for the full analytics view
- The extension tracks automatically — no setup needed!

## Dashboard Pages
| Page | Description |
|------|-------------|
| Overview | Today's productivity score, charts, top sites |
| Weekly Report | 7-day breakdown with stacked bar charts |
| All Sites | Full site list with category filters & reclassify |
| Insights | AI-generated recommendations & weekly summary |
| Settings | Notifications, custom classifications, data export |

## Productive Sites (built-in)
GitHub, GitLab, Stack Overflow, LeetCode, Figma, Notion, Coursera, Udemy, freeCodeCamp, Claude.ai, Wikipedia, arXiv, and more.

## Unproductive Sites (built-in)
Facebook, Instagram, Twitter/X, TikTok, YouTube, Netflix, Reddit, Twitch, and more.

## File Structure
```
time-tracker-extension/
├── manifest.json      # Extension config (Manifest V3)
├── background.js      # Service worker — tracks tab time
├── popup.html         # Quick-view popup UI
├── popup.js           # Popup logic
├── dashboard.html     # Full analytics dashboard
├── dashboard.js       # Dashboard charts & logic
└── icons/             # Extension icons
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

## Privacy
All data is stored **locally** in Chrome's storage. Nothing is sent to any server.
