// FocusLens Dashboard Logic

let allData = {};
let chartInstances = {};

const DAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const FULL_DAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

function fmt(secs) {
  if (!secs || secs < 1) return "0m";
  if (secs < 60) return `${secs}s`;
  if (secs < 3600) return `${Math.round(secs / 60)}m`;
  const h = Math.floor(secs / 3600);
  const m = Math.round((secs % 3600) / 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function fmtShort(secs) {
  if (!secs) return "0m";
  if (secs < 3600) return `${Math.round(secs/60)}m`;
  return `${(secs/3600).toFixed(1)}h`;
}

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function getDayKey(offset) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function score(d) {
  if (!d) return 0;
  const total = (d.productive||0) + (d.unproductive||0) + (d.neutral||0);
  return total > 0 ? Math.round(((d.productive||0) / total) * 100) : 0;
}

function scoreColor(s) {
  if (s >= 70) return "#4ade80";
  if (s >= 40) return "#fbbf24";
  return "#f87171";
}

async function loadData() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "GET_STATS" }, (res) => {
      allData = res && res.data ? res.data : {};
      document.getElementById("lastSync").textContent = "Last sync: " + new Date().toLocaleTimeString();
      resolve();
    });
  });
}

function destroyChart(id) {
  if (chartInstances[id]) {
    chartInstances[id].destroy();
    delete chartInstances[id];
  }
}

// ---- OVERVIEW ----
function renderOverview() {
  const today = getTodayKey();
  const daily = allData.dailyData || {};
  const d = daily[today] || { productive: 0, unproductive: 0, neutral: 0, sites: {} };

  document.getElementById("overviewDate").textContent = new Date().toLocaleDateString("en-IN", { weekday:"long", year:"numeric", month:"long", day:"numeric" });

  const s = score(d);
  document.getElementById("kpiScore").textContent = s + "%";
  document.getElementById("kpiScore").style.color = scoreColor(s);
  document.getElementById("kpiProd").textContent = fmt(d.productive || 0);
  document.getElementById("kpiUnprod").textContent = fmt(d.unproductive || 0);
  document.getElementById("kpiSites").textContent = Object.keys(d.sites || {}).length;

  // Donut chart
  destroyChart("donut");
  const prod = d.productive || 0, neut = d.neutral || 0, unprod = d.unproductive || 0;
  const total = prod + neut + unprod;
  chartInstances["donut"] = new Chart(document.getElementById("donutChart"), {
    type: "doughnut",
    data: {
      labels: ["Productive","Neutral","Distraction"],
      datasets: [{
        data: total > 0 ? [prod, neut, unprod] : [1, 1, 1],
        backgroundColor: total > 0 ? ["#4ade80","#6366f1","#f87171"] : ["#2a2a3e","#2a2a3e","#2a2a3e"],
        borderWidth: 0, hoverOffset: 4
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      cutout: "65%",
      plugins: {
        legend: { position:"bottom", labels: { color:"#888", font: { size: 11 }, boxWidth: 10, padding: 12 } },
        tooltip: { callbacks: { label: (ctx) => ` ${fmt(ctx.raw)} (${total > 0 ? Math.round((ctx.raw/total)*100) : 0}%)` } }
      }
    }
  });

  // Hourly/category bar chart (simulate hourly or use totals)
  destroyChart("hourly");
  chartInstances["hourly"] = new Chart(document.getElementById("hourlyChart"), {
    type: "bar",
    data: {
      labels: ["Productive","Neutral","Distraction"],
      datasets: [{
        label: "Minutes",
        data: [Math.round((d.productive||0)/60), Math.round((d.neutral||0)/60), Math.round((d.unproductive||0)/60)],
        backgroundColor: ["#4ade80","#6366f1","#f87171"],
        borderRadius: 8, borderSkipped: false
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: "#888", font: { size: 12 } } },
        y: { grid: { color: "rgba(255,255,255,.05)" }, ticks: { color: "#888", font: { size: 11 }, callback: v => v + "m" } }
      }
    }
  });

  // Top sites tables
  const sites = d.sites || {};
  const prodSites = Object.entries(sites).filter(([,v])=>v.category==="productive").sort((a,b)=>b[1].seconds-a[1].seconds).slice(0,5);
  const unprodSites = Object.entries(sites).filter(([,v])=>v.category==="unproductive").sort((a,b)=>b[1].seconds-a[1].seconds).slice(0,5);

  document.getElementById("topProd").innerHTML = prodSites.length ? prodSites.map(([h,v])=>`
    <tr><td><img src="https://www.google.com/s2/favicons?domain=${h}&sz=16" style="width:14px;height:14px;margin-right:6px;vertical-align:middle;border-radius:2px" onerror="this.style.display='none'" />${h}</td><td style="color:#4ade80">${fmt(v.seconds)}</td></tr>
  `).join("") : '<tr><td colspan="2" style="color:#555;text-align:center;padding:16px">No data yet</td></tr>';

  document.getElementById("topUnprod").innerHTML = unprodSites.length ? unprodSites.map(([h,v])=>`
    <tr><td><img src="https://www.google.com/s2/favicons?domain=${h}&sz=16" style="width:14px;height:14px;margin-right:6px;vertical-align:middle;border-radius:2px" onerror="this.style.display='none'" />${h}</td><td style="color:#f87171">${fmt(v.seconds)}</td></tr>
  `).join("") : '<tr><td colspan="2" style="color:#555;text-align:center;padding:16px">No data yet</td></tr>';
}

// ---- WEEKLY ----
function renderWeekly() {
  const daily = allData.dailyData || {};
  const last7 = Array.from({length:7},(_,i) => getDayKey(i-6));
  const today = getTodayKey();

  // Day cards
  const grid = document.getElementById("weekGrid");
  grid.innerHTML = last7.map(k => {
    const d = daily[k] || null;
    const s = score(d);
    const total = d ? (d.productive||0)+(d.unproductive||0)+(d.neutral||0) : 0;
    const date = new Date(k + "T00:00:00");
    const isToday = k === today;
    return `<div class="day-card${isToday?" today":""}">
      <div class="day-name">${DAYS[date.getDay()]}</div>
      <div class="day-score" style="color:${d ? scoreColor(s) : "#444"}">${d ? s+"%" : "—"}</div>
      <div class="day-time">${total > 0 ? fmtShort(total) : "no data"}</div>
    </div>`;
  }).join("");

  // Week bar chart
  destroyChart("week");
  chartInstances["week"] = new Chart(document.getElementById("weekChart"), {
    type: "bar",
    data: {
      labels: last7.map(k => { const d = new Date(k+"T00:00:00"); return DAYS[d.getDay()]; }),
      datasets: [
        { label:"Productive", data: last7.map(k => Math.round(((daily[k]||{}).productive||0)/60)), backgroundColor:"#4ade80", borderRadius:4, stack:"s" },
        { label:"Neutral", data: last7.map(k => Math.round(((daily[k]||{}).neutral||0)/60)), backgroundColor:"#6366f1", borderRadius:4, stack:"s" },
        { label:"Distraction", data: last7.map(k => Math.round(((daily[k]||{}).unproductive||0)/60)), backgroundColor:"#f87171", borderRadius:4, stack:"s" }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color:"#888", font:{size:11}, boxWidth:10, padding:12 } } },
      scales: {
        x: { stacked:true, grid:{display:false}, ticks:{color:"#888"} },
        y: { stacked:true, grid:{color:"rgba(255,255,255,.05)"}, ticks:{color:"#888", callback:v=>v+"m"} }
      }
    }
  });

  // Week KPIs
  const weekTotals = last7.reduce((acc, k) => {
    const d = daily[k] || {};
    acc.prod += d.productive||0;
    acc.unprod += d.unproductive||0;
    acc.neut += d.neutral||0;
    return acc;
  }, {prod:0, unprod:0, neut:0});
  const weekTotal = weekTotals.prod + weekTotals.unprod + weekTotals.neut;
  const weekScoreVal = weekTotal > 0 ? Math.round((weekTotals.prod/weekTotal)*100) : 0;

  document.getElementById("weekScore").textContent = weekScoreVal + "%";
  document.getElementById("weekScore").style.color = scoreColor(weekScoreVal);
  document.getElementById("weekProd").textContent = fmtShort(weekTotals.prod);
  document.getElementById("weekUnprod").textContent = fmtShort(weekTotals.unprod);

  // Best day
  const best = last7.map(k => ({ k, s: score(daily[k]) })).sort((a,b)=>b.s-a.s)[0];
  if (best && best.s > 0) {
    const d = new Date(best.k+"T00:00:00");
    document.getElementById("weekBest").textContent = DAYS[d.getDay()];
    document.getElementById("weekBestScore").textContent = best.s + "% productive";
  } else {
    document.getElementById("weekBest").textContent = "—";
  }
}

// ---- ALL SITES ----
function renderAllSites() {
  const allSites = allData.allSites || {};
  const search = (document.getElementById("siteSearch").value || "").toLowerCase();
  const catFilter = document.getElementById("catFilter").value;

  let entries = Object.entries(allSites).sort((a,b)=>b[1].seconds-a[1].seconds);
  if (search) entries = entries.filter(([h]) => h.includes(search));
  if (catFilter) entries = entries.filter(([,v]) => v.category === catFilter);

  const tbody = document.getElementById("allSitesTable");
  if (entries.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#555;padding:24px">No sites found</td></tr>';
    return;
  }
  tbody.innerHTML = entries.slice(0, 50).map(([host, info]) => `
    <tr>
      <td><img src="https://www.google.com/s2/favicons?domain=${host}&sz=16" style="width:14px;height:14px;margin-right:6px;vertical-align:middle;border-radius:2px" onerror="this.style.display='none'" />${host}</td>
      <td>${fmt(info.seconds)}</td>
      <td><span class="cat-pill pill-${info.category}">${info.category}</span></td>
      <td>
        <select onchange="reclassify('${host}',this.value)" style="background:#1a1a2e;border:1px solid #2a2a3e;border-radius:6px;color:#ccc;font-size:11px;padding:3px 6px;cursor:pointer">
          <option value="productive" ${info.category==="productive"?"selected":""}>Productive</option>
          <option value="unproductive" ${info.category==="unproductive"?"selected":""}>Unproductive</option>
          <option value="neutral" ${info.category==="neutral"?"selected":""}>Neutral</option>
        </select>
      </td>
    </tr>
  `).join("");
}

function reclassify(hostname, category) {
  chrome.runtime.sendMessage({ type: "ADD_CUSTOM_SITE", hostname, category }, () => {
    if (allData.allSites && allData.allSites[hostname]) {
      allData.allSites[hostname].category = category;
    }
  });
}

// ---- INSIGHTS ----
function renderInsights() {
  const daily = allData.dailyData || {};
  const last7 = Array.from({length:7},(_,i) => getDayKey(i-6));
  const weekTotals = last7.reduce((acc,k) => {
    const d = daily[k]||{};
    acc.prod += d.productive||0;
    acc.unprod += d.unproductive||0;
    acc.neut += d.neutral||0;
    return acc;
  }, {prod:0,unprod:0,neut:0});
  const total = weekTotals.prod+weekTotals.unprod+weekTotals.neut;
  const s = total > 0 ? Math.round((weekTotals.prod/total)*100) : 0;

  const allSites = allData.allSites || {};
  const topDistract = Object.entries(allSites).filter(([,v])=>v.category==="unproductive").sort((a,b)=>b[1].seconds-a[1].seconds).slice(0,3);
  const topProd = Object.entries(allSites).filter(([,v])=>v.category==="productive").sort((a,b)=>b[1].seconds-a[1].seconds).slice(0,3);

  let summaryText = `This week, your overall productivity score is <strong style="color:${scoreColor(s)}">${s}%</strong>. `;
  summaryText += `You spent <strong style="color:#4ade80">${fmtShort(weekTotals.prod)}</strong> on productive work, `;
  summaryText += `<strong style="color:#6366f1">${fmtShort(weekTotals.neut)}</strong> on neutral browsing, and `;
  summaryText += `<strong style="color:#f87171">${fmtShort(weekTotals.unprod)}</strong> on distracting websites.`;

  if (s >= 70) summaryText += " 🌟 Excellent work — you're highly focused!";
  else if (s >= 50) summaryText += " 👍 You're doing well, but there's room to improve.";
  else summaryText += " ⚠️ Your distraction time is high — consider blocking distracting sites.";

  document.getElementById("summaryText").innerHTML = summaryText;

  const insights = [];
  if (topDistract.length > 0) insights.push({ icon:"⚠️", text:`Your top distraction is <strong>${topDistract[0][0]}</strong>`, sub:`You've spent ${fmt(topDistract[0][1].seconds)} on it this week` });
  if (topProd.length > 0) insights.push({ icon:"✅", text:`Most productive on <strong>${topProd[0][0]}</strong>`, sub:`${fmt(topProd[0][1].seconds)} of focused work` });
  if (weekTotals.unprod > 3600) insights.push({ icon:"💡", text:"Consider using a site blocker during work hours", sub:`You spent ${fmtShort(weekTotals.unprod)} on distracting sites` });
  if (s >= 70) insights.push({ icon:"🏆", text:"Keep it up! Your streak is strong", sub:"You're consistently productive this week" });
  else insights.push({ icon:"🎯", text:"Set a daily productivity goal of 75%+", sub:"Small improvements each day add up" });
  insights.push({ icon:"⏰", text:"Track your peak focus hours", sub:"Use the daily overview to find when you're most productive" });

  document.getElementById("insightsList").innerHTML = insights.map(ins => `
    <div class="insight-item">
      <div class="insight-icon">${ins.icon}</div>
      <div><div class="insight-text">${ins.text}</div><div class="insight-sub">${ins.sub}</div></div>
    </div>
  `).join("");
}

// ---- SETTINGS ----
function renderSettings() {
  chrome.storage.local.get("customClassifications").then(r => {
    const custom = r.customClassifications || {};
    document.getElementById("customList").innerHTML = Object.keys(custom).length ? Object.entries(custom).map(([h,c]) => `
      <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid rgba(42,42,62,.6)">
        <span style="flex:1;font-size:13px;color:#ccc">${h}</span>
        <span class="cat-pill pill-${c}">${c}</span>
        <button onclick="removeCustom('${h}')" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:14px">✕</button>
      </div>
    `).join("") : '<p style="font-size:12px;color:#555">No custom classifications yet.</p>';
  });
}

function addCustomSite() {
  const host = document.getElementById("customHost").value.trim().replace(/^www\./,"");
  const cat = document.getElementById("customCat").value;
  if (!host) return;
  chrome.runtime.sendMessage({ type:"ADD_CUSTOM_SITE", hostname:host, category:cat }, () => {
    document.getElementById("customHost").value = "";
    renderSettings();
  });
}

function removeCustom(hostname) {
  chrome.storage.local.get("customClassifications").then(r => {
    const c = r.customClassifications || {};
    delete c[hostname];
    chrome.storage.local.set({ customClassifications: c }).then(renderSettings);
  });
}

function exportJSON() {
  const blob = new Blob([JSON.stringify(allData, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `focuslens-data-${getTodayKey()}.json`;
  a.click();
}

function exportCSV() {
  const allSites = allData.allSites || {};
  const rows = [["Domain","Total Seconds","Total Time","Category"]];
  Object.entries(allSites).sort((a,b)=>b[1].seconds-a[1].seconds).forEach(([h,v]) => {
    rows.push([h, v.seconds, fmt(v.seconds), v.category]);
  });
  const csv = rows.map(r => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `focuslens-sites-${getTodayKey()}.csv`;
  a.click();
}

function clearData() {
  if (!confirm("Are you sure you want to clear all tracking data? This cannot be undone.")) return;
  chrome.runtime.sendMessage({ type: "CLEAR_DATA" }, () => {
    allData = {};
    init();
  });
}

// ---- NAV ----
let currentPage = "overview";
function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
  document.getElementById("page-" + page).classList.add("active");
  document.querySelectorAll(".nav-item").forEach(n => {
    if (n.textContent.toLowerCase().includes(page.replace("_","")) || 
        (page==="weekly" && n.textContent.includes("Weekly")) ||
        (page==="sites" && n.textContent.includes("Sites")) ||
        (page==="insights" && n.textContent.includes("Insights")) ||
        (page==="settings" && n.textContent.includes("Settings")) ||
        (page==="overview" && n.textContent.includes("Overview"))) {
      n.classList.add("active");
    }
  });
  currentPage = page;
  renderPage(page);
}

function renderPage(page) {
  if (page === "overview") renderOverview();
  else if (page === "weekly") renderWeekly();
  else if (page === "sites") renderAllSites();
  else if (page === "insights") renderInsights();
  else if (page === "settings") renderSettings();
}

async function init() {
  await loadData();
  renderPage(currentPage);
}

init();
setInterval(async () => {
  await loadData();
  renderPage(currentPage);
}, 30000);
