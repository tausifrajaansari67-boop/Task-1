function fmt(secs) {
  if (!secs || secs < 60) return secs ? `${secs}s` : "0s";
  if (secs < 3600) return `${Math.round(secs / 60)}m`;
  const h = Math.floor(secs / 3600);
  const m = Math.round((secs % 3600) / 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function calcStreak(dailyData) {
  const keys = Object.keys(dailyData).sort().reverse();
  const today = getTodayKey();
  let streak = 0;
  let check = new Date();
  for (let i = 0; i < 60; i++) {
    const key = `${check.getFullYear()}-${String(check.getMonth()+1).padStart(2,"0")}-${String(check.getDate()).padStart(2,"0")}`;
    const d = dailyData[key];
    if (!d) break;
    const total = (d.productive || 0) + (d.unproductive || 0) + (d.neutral || 0);
    const score = total > 0 ? (d.productive || 0) / total : 0;
    if (score >= 0.5 || key === today) streak++;
    else break;
    check.setDate(check.getDate() - 1);
  }
  return streak;
}

async function loadData() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "GET_STATS" }, (res) => {
      resolve(res && res.data ? res.data : {});
    });
  });
}

async function render() {
  const data = await loadData();
  const today = getTodayKey();
  const daily = data.dailyData || {};
  const todayData = daily[today] || { productive: 0, unproductive: 0, neutral: 0, sites: {} };

  const prod = todayData.productive || 0;
  const unprod = todayData.unproductive || 0;
  const neut = todayData.neutral || 0;
  const total = prod + unprod + neut;
  const score = total > 0 ? Math.round((prod / total) * 100) : 0;

  document.getElementById("scoreVal").textContent = score;
  const badge = document.getElementById("scoreBadge");
  if (score >= 70) { badge.textContent = "🌟 Great"; badge.className = "score-badge badge-great"; }
  else if (score >= 40) { badge.textContent = "👍 Good"; badge.className = "score-badge badge-good"; }
  else { badge.textContent = "💤 Improve"; badge.className = "score-badge badge-poor"; }

  document.getElementById("barProd").style.width = total > 0 ? `${(prod/total)*100}%` : "0%";
  document.getElementById("barNeut").style.width = total > 0 ? `${(neut/total)*100}%` : "0%";
  document.getElementById("barUnprod").style.width = total > 0 ? `${(unprod/total)*100}%` : "0%";

  document.getElementById("prodTime").textContent = `${fmt(prod)} productive`;
  document.getElementById("neutTime").textContent = `${fmt(neut)} neutral`;
  document.getElementById("unprodTime").textContent = `${fmt(unprod)} distraction`;

  const sites = todayData.sites || {};
  const siteCount = Object.keys(sites).length;
  document.getElementById("statTotal").textContent = fmt(total);
  document.getElementById("statSites").textContent = siteCount;
  document.getElementById("statStreak").textContent = `${calcStreak(daily)}🔥`;

  const siteList = document.getElementById("siteList");
  const sorted = Object.entries(sites).sort((a, b) => b[1].seconds - a[1].seconds).slice(0, 6);

  if (sorted.length === 0) {
    siteList.innerHTML = '<div class="empty"><span>⏱️</span>No data yet. Browse some sites!</div>';
  } else {
    siteList.innerHTML = sorted.map(([host, info]) => `
      <div class="site-row">
        <div class="site-left">
          <div class="site-favicon">
            <img src="https://www.google.com/s2/favicons?domain=${host}&sz=32"
              onerror="this.parentElement.textContent='🌐'" />
          </div>
          <span class="site-name">${host}</span>
        </div>
        <div class="site-right">
          <span class="site-time">${fmt(info.seconds)}</span>
          <span class="cat-badge cat-${info.category}">${info.category}</span>
        </div>
      </div>
    `).join("");
  }

  // Current tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url) {
      try {
        const host = new URL(tabs[0].url).hostname.replace(/^www\./, "");
        if (host && !host.startsWith("chrome")) {
          document.getElementById("currentSite").style.display = "flex";
          document.getElementById("currentSiteName").textContent = host;
        }
      } catch {}
    }
  });
}

document.getElementById("btnDashboard").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});
document.getElementById("btnOpenDash").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});
document.getElementById("btnRefresh").addEventListener("click", render);
document.getElementById("btnSettings").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

render();
