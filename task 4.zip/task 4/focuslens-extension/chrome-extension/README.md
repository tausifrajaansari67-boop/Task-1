# FocusLens — Chrome Extension
## Time Tracking & Productivity Analytics

A powerful Chrome Extension that tracks time spent on websites, classifies them as productive or unproductive, and gives you beautiful weekly analytics reports.

---

## Installation Instructions

### Step 1 — Download & Extract
Extract the `focuslens-extension.zip` file to a folder on your computer (e.g. `Desktop/focuslens`).

### Step 2 — Open Chrome Extensions
1. Open **Google Chrome**
2. Go to the address bar and type: `chrome://extensions`
3. Press **Enter**

### Step 3 — Enable Developer Mode
- In the top-right corner of the Extensions page, toggle **"Developer mode"** ON

### Step 4 — Load the Extension
1. Click **"Load unpacked"** button (top-left)
2. Navigate to and select the extracted `focuslens` folder
3. Click **"Select Folder"**

### Step 5 — Pin it!
- Click the puzzle icon (🧩) in Chrome's toolbar
- Find **FocusLens** and click the pin icon to keep it visible

---

## Features

### Popup (click the extension icon)
- **Current site** — shows the active domain with productive/unproductive/neutral badge
- **Live timer** — counts how long you've been on the current page
- **Mark buttons** — instantly reclassify any site
- **Today's score** — productive vs unproductive hours with visual bars
- **Top 5 sites** — most visited today
- **Productivity ring** — your score at a glance

### Full Dashboard (click "Full Dashboard →" in popup, or right-click extension → Options)
- **Overview tab** — metrics, hourly chart, donut breakdown, top sites (today / this week / all time)
- **All Sites tab** — complete table with per-site time across all periods
- **Weekly Report tab** — past weekly summaries with heatmaps and scores
- **Settings tab** — add/remove productive & unproductive sites, toggle preferences

---

## How It Works

| Category | Examples |
|---|---|
| **Productive** | github.com, stackoverflow.com, notion.so, figma.com, coursera.org, leetcode.com |
| **Unproductive** | youtube.com, instagram.com, tiktok.com, reddit.com, netflix.com |
| **Neutral** | Everything else (news, shopping, etc.) |

- Time is tracked per-domain in real time
- Tracking pauses when the computer goes idle (5+ min)
- Data is stored locally in Chrome's storage — fully private
- Weekly report notification fires every Monday

---

## Files Overview

```
focuslens/
├── manifest.json      — Extension config (Manifest V3)
├── background.js      — Service worker: tracks tabs, saves time, sends reports
├── popup.html         — Extension popup UI
├── dashboard.html     — Full analytics dashboard (Options page)
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## Tech Stack
- **Manifest V3** Chrome Extension API
- **chrome.storage.local** — persistent data store
- **chrome.tabs / chrome.windows** — tab focus detection
- **chrome.idle** — idle state detection
- **chrome.alarms** — periodic saves & weekly reports
- **Vanilla JS** — zero dependencies, fast and lightweight
- **Google Fonts** — Space Mono + DM Sans

---

*Built for FocusLens v1.0*
