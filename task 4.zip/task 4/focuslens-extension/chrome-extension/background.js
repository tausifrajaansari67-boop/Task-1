// FocusLens Background Service Worker
// Tracks active tab time, classifies sites, manages weekly reports

const PRODUCTIVE_SITES = [
  'github.com','gitlab.com','stackoverflow.com','leetcode.com','codepen.io',
  'developer.mozilla.org','docs.google.com','notion.so','linear.app','jira.atlassian.com',
  'confluence.atlassian.com','figma.com','trello.com','asana.com','slack.com',
  'zoom.us','meet.google.com','coursera.org','udemy.com','edx.org','khanacademy.org',
  'medium.com','dev.to','hashnode.com','npmjs.com','pypi.org','docs.python.org',
  'w3schools.com','freecodecamp.org','codecademy.com','replit.com','codesandbox.io',
  'vercel.com','netlify.com','railway.app','cloud.google.com','aws.amazon.com',
  'azure.microsoft.com','digitalocean.com','heroku.com','mongodb.com','postgresql.org'
];

const UNPRODUCTIVE_SITES = [
  'youtube.com','facebook.com','instagram.com','twitter.com','x.com','tiktok.com',
  'reddit.com','snapchat.com','pinterest.com','tumblr.com','twitch.tv','netflix.com',
  'hulu.com','disneyplus.com','primevideo.com','hbomax.com','spotify.com',
  'buzzfeed.com','9gag.com','ifunny.co','vine.co','discord.com','whatsapp.com',
  'telegram.org','messenger.com','dating.com','tinder.com','bumble.com'
];

let activeTabId = null;
let activeUrl = null;
let activeStartTime = null;
let isUserActive = true;

function getDomain(url) {
  try {
    if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) return null;
    const u = new URL(url);
    return u.hostname.replace(/^www\./, '');
  } catch { return null; }
}

function classify(domain) {
  if (!domain) return 'neutral';
  if (PRODUCTIVE_SITES.some(s => domain === s || domain.endsWith('.' + s))) return 'productive';
  if (UNPRODUCTIVE_SITES.some(s => domain === s || domain.endsWith('.' + s))) return 'unproductive';
  return 'neutral';
}

function todayKey() {
  return new Date().toISOString().split('T')[0];
}

function weekKey() {
  const d = new Date();
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const mon = new Date(d.setDate(diff));
  return mon.toISOString().split('T')[0];
}

async function saveTime(domain, seconds) {
  if (!domain || seconds < 1) return;
  const today = todayKey();
  const week = weekKey();
  const category = classify(domain);

  const result = await chrome.storage.local.get(['dailyData', 'weeklyData', 'allTime']);
  const daily = result.dailyData || {};
  const weekly = result.weeklyData || {};
  const allTime = result.allTime || {};

  if (!daily[today]) daily[today] = {};
  if (!daily[today][domain]) daily[today][domain] = { seconds: 0, category };
  daily[today][domain].seconds += seconds;

  if (!weekly[week]) weekly[week] = {};
  if (!weekly[week][domain]) weekly[week][domain] = { seconds: 0, category };
  weekly[week][domain].seconds += seconds;

  if (!allTime[domain]) allTime[domain] = { seconds: 0, category };
  allTime[domain].seconds += seconds;

  await chrome.storage.local.set({ dailyData: daily, weeklyData: weekly, allTime });
}

async function flushCurrent() {
  if (!activeUrl || !activeStartTime || !isUserActive) return;
  const domain = getDomain(activeUrl);
  if (!domain) return;
  const elapsed = Math.floor((Date.now() - activeStartTime) / 1000);
  activeStartTime = Date.now();
  await saveTime(domain, elapsed);
}

async function switchTo(url, tabId) {
  await flushCurrent();
  activeTabId = tabId;
  activeUrl = url;
  activeStartTime = Date.now();
}

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    await switchTo(tab.url, tabId);
  } catch {}
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tabId === activeTabId) {
    await switchTo(tab.url, tabId);
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await flushCurrent();
    activeStartTime = null;
  } else {
    try {
      const [tab] = await chrome.tabs.query({ active: true, windowId });
      if (tab) await switchTo(tab.url, tab.id);
    } catch {}
  }
});

chrome.idle.onStateChanged.addListener(async (state) => {
  isUserActive = state === 'active';
  if (!isUserActive) {
    await flushCurrent();
    activeStartTime = null;
  } else {
    activeStartTime = Date.now();
  }
});

// Periodic flush every 30 seconds
chrome.alarms.create('flush', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'flush') await flushCurrent();
  if (alarm.name === 'weeklyReport') await sendWeeklyReport();
});

// Schedule weekly report every Monday
chrome.alarms.create('weeklyReport', { periodInMinutes: 10080 });

async function sendWeeklyReport() {
  const result = await chrome.storage.local.get(['weeklyData']);
  const weekly = result.weeklyData || {};
  const keys = Object.keys(weekly).sort();
  if (keys.length === 0) return;
  const lastWeek = weekly[keys[keys.length - 1]];
  let productive = 0, unproductive = 0, neutral = 0;
  for (const d of Object.values(lastWeek)) {
    if (d.category === 'productive') productive += d.seconds;
    else if (d.category === 'unproductive') unproductive += d.seconds;
    else neutral += d.seconds;
  }
  const total = productive + unproductive + neutral;
  const pct = total > 0 ? Math.round((productive / total) * 100) : 0;
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'FocusLens Weekly Report',
    message: `Productivity score: ${pct}%. Productive: ${Math.round(productive/3600)}h, Unproductive: ${Math.round(unproductive/3600)}h`
  });
}

// Message handler for popup/dashboard queries
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_CURRENT') {
    const domain = getDomain(activeUrl);
    const elapsed = activeStartTime ? Math.floor((Date.now() - activeStartTime) / 1000) : 0;
    sendResponse({ domain, category: classify(domain), elapsed });
  }
  if (msg.type === 'FLUSH') {
    flushCurrent().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === 'ADD_PRODUCTIVE') {
    PRODUCTIVE_SITES.push(msg.domain);
    sendResponse({ ok: true });
  }
  if (msg.type === 'ADD_UNPRODUCTIVE') {
    UNPRODUCTIVE_SITES.push(msg.domain);
    sendResponse({ ok: true });
  }
});
